.dgcOptions <- as.environment(list(
                                   default.alleles=c("A", "B"),
                                   allele.sep="/",
                                   locus.sep="-",
                                   name.sep=".",
                                   id.sep=":"
                              ))

dgcOptions <- function(...) {
  values <- list(...)
  options <- names(values)
  nset <- length(values)
  if (nset>0) {
    for (i in 1:length(values)) {
      assign(options[i], values[[i]], env=.dgcOptions)
    }
  }
  as.list(.dgcOptions)
}

## Genotype class


Genotype <-
  function(x) {
    if(is.null(x)) {
      stop("object is null");
    }
    gn <- levels(x)
    gp <- gparse(gn)
    if (is.null(gp)) {
      if (nlevels(x)!=3)
        stop("factor cannot be coerced as a diallelic Genotype")
      a <- dgcOptions()$default.alleles
      asep <- dgcOptions()$allele.sep
      attr(x, "allele.names") <- a
      attr(x, "allele.map") <- matrix(c(1,1,2,1,2,2), ncol=2)
      levels(x) <- paste(c(a[1], a[1], a[2]),
                         c(a[1], a[2], a[2]), sep=asep)
    } else {
      attr(x, "allele.names") <- gp$alleles
      attr(x, "allele.map") <- gp$map
    }
    class(x) <- c("Genotype", "factor")
    x
  }


## Ordered Genotype class

OrderedGenotype <-
  function(x) {
    if(is.null(x)) {
      stop("object is null");
    }
    gn <- levels(x)
    gp <- gparse(gn)
    if (is.null(gp)) {
      if (nlevels(x)!=4)
        stop("factor cannot be coerced as a diallelic Genotype")
      a <- dgcOptions()$default.alleles
      asep <- dgcOptions()$allele.sep
      attr(x, "allele.names") <- a
      attr(x, "allele.map") <- matrix(c(1,1,2,2,1,2,1,2), ncol=2)
      levels(x) <- paste(c(a[1], a[1], a[2], a[2]),
                         c(a[1], a[2], a[1], a[2]), sep=asep)
    } else {
      attr(x, "allele.names") <- gp$alleles
      attr(x, "allele.map") <- gp$map
    }
    class(x) <- c("OrderedGenotype", "Genotype", "factor")
    x
  }

## Internal functions

gparse <- function(gnames, ordered=FALSE) {
  nchars <- nchar(gnames)
  if (all(nchars==2)) {
    a1 <- substr(gnames, 1, 1)
    a2 <- substr(gnames, 2, 2)
  } else {
    alist <- strsplit(gnames, split=dgcOptions()$allele.sep)
    if (any(sapply(alist, length)!=2)) {
      warning("could not parse genotype names(1): ",
              paste(gnames, collapse=", "))
      return(NULL)
    }
    a1 <- sapply(alist, '[', 1)
    a2 <- sapply(alist, '[', 2)
  }
  alleles <- sort(unique(c(a1, a2)))
  na <- length(alleles)
  i1 <- match(a1, alleles)
  i2 <- match(a2, alleles)
  if (ordered) {
    i12 <- na*(i2-1)+i1
  } else {
    j1 <- ifelse(i1<i2, i1, i2)
    j2 <- ifelse(i1<i2, i2, i1)
    i12 <- (j2*(j2-1))/2 + j1
    if (any(duplicated(i12)))
      stop("factor seems to represent an ordered genotype")
  }
  list(alleles=alleles, map=cbind(i1, i2))
}

## Allele pairs

allelePair <- function(g) {
  if (!is.Genotype(g) && !is.OrderedGenotype(g))
    stop("argument must be of class Genotype")
  map <- attr(g, "allele.map")
  alleles <- attr(g, "allele.names")
  matrix(alleles[map[as.numeric(g),]], ncol=2)
}

is.AllelePair <- function(x) is.character(x) && is.matrix(x) && ncol(x)==2
         
## Unphase an allele pair matrix

unphase <- function(g) {
  if (ncol(g)!=2)
    stop("not an allele pair matrix")
  sw <- g[,1]>g[,2]
  r1 <- ifelse(sw, g[,2], g[,1])
  r2 <- ifelse(sw, g[,1], g[,2])
  cbind(r1, r2)
}

## Bind multiple allele pair matrices together 

hbind <- function(...) {
  args <- list(...)
  if (length(args)==1 && is.list(args[[1]]))
    args <- args[[1]]
  nl <- length(args)
  if (nl<=1)
    stop("Too few arguments or list elements")
  first <- args[[1]]
  if (is.AllelePair(first)) {
    hap <- first
  }
  else if(is.Genotype(first) || is.OrderedGenotype(first)) {
    hap <- allelePair(first)
  }
  else
    stop("Illegal allele pair argument or list element")
  lsep <- dgcOptions()$locus.sep
  for (i in 2:nl) {
    ht <- args[[i]]
    if (is.Genotype(ht) || is.OrderedGenotype(ht)) {
      ht <- allelePair(ht)
    }
    else if (!is.AllelePair(ht))
      stop("Illegal allele pair argument or list element")
    hap[,1] <- ifelse(is.na(hap[,1])|is.na(ht[,1]), NA,
                      paste(hap[,1], ht[,1], sep=lsep))
    hap[,2] <- ifelse(is.na(hap[,2])|is.na(ht[,2]), NA,
                      paste(hap[,2], ht[,2], sep=lsep))
  }
  hap
}

## As functions

pair2genotype <- function(pair, ordered) {
  if (!is.AllelePair(pair))
    stop("not an allele pair matrix")
  if (!is.character(pair))
    pair <- matrix(as.character(pair), ncol=2, byrow=FALSE)
  alleles <- sort(unique(as.vector(pair)))
  na <- length(alleles)
  if (!ordered)
    pair <- unphase(pair)
  i1 <- match(pair[,1], alleles)
  i2 <- match(pair[,2], alleles)
  if (ordered) {
    i12 <- i1 + na*(i2-1)
    ng <- na^2
  } else {
    j1 <- ifelse(i1<i2, i1, i2)
    j2 <- ifelse(i1<i2, i2, i1)
    i12 <- (j2*(j2-1))/2 + j1
    ng <- (na*(na+1))/2
  }
  i1 <- rep(1:na, na)
  i2 <- rep(1:na, rep(na, na))
  map <- cbind(i1, i2)
  genotypes <- paste(rep(alleles, na), rep(alleles, rep(na, na)),
                     sep=dgcOptions()$allele.sep)
  if ( ordered) {
    gclass <- c("OrderedGenotype", "Genotype")
  } else {
    gclass <- "Genotype"
    upper <- i1<=i2
    map <- map[upper,]
    genotypes <- genotypes[upper]
  }
  f <- factor(i12, levels=1:ng, labels=genotypes)
  attr(f, "allele.names") <- alleles
  attr(f, "allele.map") <- map
  class(f) <- c(gclass, "factor")
  f
}

as.Genotype <- function(x) {
  if (is.Genotype(x))
    return(x)
  if (is.character(x) && is.matrix(x) && ncol(x)==2)
    return(pair2genotype(x, FALSE))
  Genotype(x)
}

as.OrderedGenotype <- function(x) {
  if (is.OrderedGenotype(x))
    return(x)
  if (is.character(x) && is.matrix(x) && ncol(x)==2)
    return(pair2genotype(x, TRUE))
  OrderedGenotype(x)
}

## Subset operator

`[.Genotype` <- function(x, ..., drop=FALSE) {
  y <- NextMethod("[")
  attr(y, "contrasts") <- attr(x, "contrasts")
  attr(y, "levels") <- attr(x, "levels")
  attr(y, "allele.names") <- attr(x, "allele.names") 
  attr(y, "allele.map") <- attr(x, "allele.map") 
  class(y) <- oldClass(x)
  lev <- levels(x)
  if (drop) 
    factor(y, exclude = if (any(is.na(levels(x)))) 
           NULL
    else NA)
  else y
}

`[.OrderedGenotype` <- function(x, ..., drop=FALSE) {
  y <- NextMethod("[")
  attr(y, "contrasts") <- attr(x, "contrasts")
  attr(y, "levels") <- attr(x, "levels")
  attr(y, "allele.names") <- attr(x, "allele.names") 
  attr(y, "allele.map") <- attr(x, "allele.map") 
  class(y) <- oldClass(x)
  lev <- levels(x)
  if (drop) 
    factor(y, exclude = if (any(is.na(levels(x)))) 
           NULL
    else NA)
  else y
}

is.Genotype <- function(x) inherits(x, "Genotype")
is.OrderedGenotype <- function(x) inherits(x, "OrderedGenotype")

## Allele incidence matrix

alleleInc <- function(g) {
  map <- attr(g, "allele.map")
  inc <- table(rep(1:nrow(map), 2), map)
  mat <- inc[as.numeric(g),]
  colnames(mat) <- attr(g, "allele.names")
  mat
}

## Generalised Additive contrasts

addContr <- function(g, base=1) {
  if (!is.Genotype(g))
    stop("not a Genotype variable")
  if (is.character(base)) {
    base <- match(base, attr(g, "allele.names"))
    if (is.na(base))
      warning("illegal base allele - ignored")
  }
  map <-  attr(g, "allele.map")
  inc <- table(rep(1:nrow(map), 2), map)
  colnames(inc) <- attr(g, "allele.names")
  names(dimnames(inc))[2] <- "Allele"
  if (!is.na(base))
    inc <- inc[, -base, drop=FALSE]
  contrasts(g, ncol(inc)) <- inc
  g
}
  
