# Clear the workspace of all objects whose names don't start with a full stop

clear <- function()  {
  env <- as.environment(1)
  to.go <- ls(env, all.names=FALSE)
  continue <- TRUE
  while (continue) {
    nxt <- search()[[2]]
    # bit of a botch
    if (substr(nxt, 1, 8)!="package:") 
      detach()
    else
      continue <- FALSE
    }
  remove(list=to.go, envir=env)
}

# Simple logistic regression wrapper

logistic <- function(formula, weights) {
  if (missing(weights))
    res <- glm(formula, family=binomial)
  else {
    wt <- weights
    res <- glm(formula, family=binomial, weights=wt)
  }
  class(res) <- c("logistic", "glm", "lm")
  res$call$formula <- formula
  res
}

print.logistic <- function(x, ...) {
  sx <- summary(x)
  beta <- sx$coefficients
  intcp <- match("(Intercept)", rownames(beta))
  if (!is.na(intcp)) {
    beta <- beta[-intcp,,drop=FALSE]
  }
  or <- matrix(nrow=nrow(beta), ncol=5)
  rownames(or) <- rownames(beta)
  colnames(or) <- c("OR", "Lower",
                    "Upper", "z-test", "P-value")
  or[,1] <- exp(beta[,1])
  or[,2] <- exp(beta[,1]-1.96*beta[,2])
  or[,3] <- exp(beta[,1]+1.96*beta[,2])
  or[,4] <- beta[,3]
  or[,5] <- beta[,4]
  cat("Logistic regression: ", deparse(sx$call$formula), "\n\n")
  cat("Odds ratios (1 unit change), lower and upper confidence limits, and tests:\n\n")
  print(or)
}
  
# Find most representative member of each cluster in a hierarchical clustering
# clusters: object calculated either by rect.hclust or by cutree
# In case of ties, select member with highest value for tie.break

representative <- function(clusters, distance, minimize="mean", tie.break){
  cri <- match(minimize, c("mean", "maximum"))
  if (is.na(cri))
    stop("minimize argument should be mean or  minimum") 
  if (class(distance)=="dist") {
    distance <- as.matrix(distance)
  }
  else if (!is.matrix(distance)) 
    stop("distance argument must be a distance object or a matrix")
  N <- nrow(distance)
  if (!is.list(clusters)) {
    if (length(clusters)!=N)
      stop("Incorrect length for clusters argument")
    ncl <- max(clusters)
    nms <- names(clusters)
    new <- vector("list", ncl)
    ord <- 1:N
    for (i in 1:ncl) {
      cli <- ord[clusters==i]
      names(cli) <- nms[clusters==i]
      new[[i]] <- cli
    }
    clusters <- new
  }   
  ncl <- length(clusters)
  if (missing(tie.break))
    tie.break <- runif(N)
  else if (length(tie.break)!=N)
    stop("tie.break argument has the wrong length")
  diag(distance) <- NA
  reps <- numeric(ncl)
  nreps <- character(ncl)
  dreps <- numeric(ncl)
  for (i in 1:ncl) {
    cli <- clusters[[i]]
    nmi <- names(cli)
    size <- length(cli)
    if (size==1) {
      reps[i] <- cli[1]
      nreps[i] <- nmi[1]
      dreps[i] <- 0
    }
    else {
      di <- distance[cli, cli]
      pri <- tie.break[cli]
      if (cri==1) 
        ds <- apply(di, 1, mean, na.rm=TRUE)
      else
        ds <- apply(di, 1, max, na.rm=TRUE)
      best <- min(ds)
      cand <- best==ds
      if (sum(cand)==1) {
        reps[i] <- cli[cand]
        nreps[i] <- nmi[cand]
      }
      else {
        maxpr <- max(pri[cand])
        ch <- (1:size)[cand]
        which <- ch[match(maxpr, pri[cand])]
        reps[i] <- cli[which]
        nreps[i] <- nmi[which]
      }
      dreps[i] <- best
    }
  }
  names(reps) <- nreps
  names(dreps) <- nreps
  isr <- rep(FALSE, N)
  isr[reps] <- TRUE
  list(rep=reps, is.rep=isr, dist=dreps)
}
  
# Weighted table

wTable <- function(..., weights) {
  by <- list(...)
  if (missing(weights))
    table(by)
  else {
    tw <- tapply(weights, by, sum, na.rm=TRUE)
    tw[is.na(tw)] <- 0
    tw
  }
}
    
    
# Table of means

meanTable <- function(x, ..., weights) {
  by <- list(...)
  if (missing(weights)) 
    tapply(x, by, mean, na.rm=TRUE)
  else {
    num <- tapply(x*weights, by, sum, na.rm=TRUE)
    den <- tapply(weights, by, sum, na.rm=TRUE)
    num/den
  }
}

# Cochran-Armitage test - with Mantel extension
# See Clayton & Hills 20.3 pp 201-203

CochranArmitageTest <- function(exposure, cc, stratum=rep(1,length(cc))) {
  N <- length(cc)
  if (is.factor(exposure)) {
    if (is.ordered(exposure))
      exposure <- as.numeric(exposure)
    else
      stop("exposure argument must be numeric or an ordered factor")
  } else {
    if (!is.numeric(exposure))
      stop("exposure must be numeric or an ordered factor")
  }
  cl <- match.call()
  narg <- length(cl) - 1
  arguments <- character(narg)
  for (i in 1:narg) {
    argi <- as.character(cl[[i+1]])
    arguments[i] <- paste(argi, collapse=".")
  }
  use <- !(is.na(cc) | is.na(exposure) | is.na(stratum))
  if (any(!use)) {
    cc <- cc[use]
    exposure <- exposure[use]
    stratum <- stratum[use]
  }
  dh <- table(stratum, cc)
  if (ncol(dh)!=2)
    stop("cc argument must have two levels")
  nt <- table(stratum)
  zm <- tapply(exposure, list(stratum, cc), mean)
  ut <- dh[,1]*dh[,2]*(zm[,1] - zm[,2])/nt
  zv <- tapply(exposure, stratum, var)
  vt <-  dh[,1]*dh[,2]*zv/nt
  x2 <- sum(ut, na.rm=TRUE)^2/sum(vt, na.rm=TRUE)
  names(x2) <- "Chi-squared"
  df <- 1
  names(df) <- "df"
  res <- list(statistic=x2, parameter=df,
              p.value=pchisq(x2, 1, lower.tail=FALSE),
              method="Cochran-Armitage test with Mantel's extension",
              data.name=paste(arguments, paste=" "),
              score=ut,
              score.variance=vt)
  class(res) <- "htest"
  res
}

