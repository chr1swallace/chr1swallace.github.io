## Test for Genotype, Ordered Genotype, and SNP

is.Snp <- function(x) (is.Genotype(x) && length(attr(x, "allele.names"))==2)

## HWE test

hweSNP <- function(g) {
  if (!is.Snp(g))
    stop("argument must be a diallelic Genotype or OrderedGenotype")
  DNAME <- deparse(substitute(g))
  f <- table(g)
  map <- attr(g, "allele.map")
  two <- map==attr(g, "allele.names")[2]
  twos <- two[,1]+two[,2]
  N <- sum(f)
  af <- sum(twos*f)/(2*N)
  if (af==0 || af==1)
    stop("Monomorphic marker")
  e <- N*c((1-af)^2, 2*af*(1-af), af^2)
  if (is.OrderedGenotype(g))
    f <- c(f[twos==0], sum(f[twos==1]), f[twos==2])
  else
    f <- f[twos+1]
  z <- sign(e[2]-f[2])*sqrt(sum((f-e)^2/e))
  names(z) <- "SND"
  res <- list(statistic=z,
              method="z test (Obs - Exp) heterozygosity",
              data.name=DNAME,
              p.value=pchisq(z^2, df=1, lower.tail=FALSE),
              observed=f,
              expected=e,
              residuals=(f-e)/sqrt(e))
  class(res) <- "htest"
  res
}

## Allele counting ... from data

countAlleles <- function(g, ...) {
  aa <- allelePair(g)
  call <- match.call()
  len <- length(call) -1
  fn <- character(len)
  for (i in 1:len)
    fn[i] <- deparse(call[[i+1]])
  rst <- list(...)
  if (length(rst)>0) {
    df1 <- data.frame(Allele=aa[,1], rst)
    names(df1) <- fn
    df2 <- data.frame(Allele=aa[,2], rst)
    names(df2) <- fn
    table(rbind(df1, df2))
  }
  else
    table(rbind(aa[,1], aa[,2]))
}

## ... from table of genotype counts

alleleCount <- function(x) {
  if (!is.array(x))
    stop("Argument must be an array")
  gnames <- dimnames(x)[[1]]
  print(gnames)
  gp <- gparse(gnames)
  if (is.null(gp))
    stop("first dimension does not seem to represent a genotype")
  xm <- matrix(x, nrow=length(gnames))
  na <- length(gp$alleles)
  ng <- nrow(gp$map)
  pre <- matrix(0, nrow=na, ncol=ng)
  for (a in 1:na) 
    pre[a,] <- (gp$map[,1]==a) + (gp$map[,2]==a)
  ndim <- dim(x)
  ndim[1] <- 2
  names(ndim) <- names(dim(x))
  ndimnames <- dimnames(x)
  ndimnames[[1]] <- gp$alleles
  array(pre %*% xm, dim=ndim, dimnames=ndimnames)
}     

## Contrasts for SNPs

snpContr <- function(g, df=1) {
  if (!is.Snp(g))
    stop("argument must be a diallelic Genotype or OrderedGenotype")
  if (df>2 && !is.OrderedGenotype(g))
    stop("argument must be an Ordered Genotype")
  map <- attr(g, "allele.map")
  cmat <- cbind(Additive=map[,1]+map[,2]-2,
                 Dominance=(map[,1]!=map[,2])/2,
                 Origin=(map[,1]-map[,2])/2)
  contrasts(g, df) <- cmat
  g
}

## More general version?
