## Replace missing genotypes with possible values
## Returns new vector of pairs of alleles, with another object which
## shows the position of the newlines in the old matrix 
## Note that order of alleles is assumed unknown
## if.expand is an array which controls, for each subject, whether
## missing genotypes should be expanded (or scalar TRUE or FALSE)

expand.missing.genotype <- function(mat, alleles, if.expand=TRUE) {
  if (missing(alleles)) {
    vals <- unique(as.vector(mat))
    alleles <- vals[!is.na(vals)]
  }
  nall <- length(alleles)
  g1 <- rep(alleles, nall)
  g2 <- rep(alleles, rep(nall, nall))
  keep <- ! (g1 > g2)
  g1 <- g1[keep]
  g2 <- g2[keep]
  ngen <- sum(keep)
  na1 <- is.na(mat[,1])
  na2 <- is.na(mat[,2]) 
  if (!(if.expand && any(na1 | na2)))
    return(NULL)
  miss1 <- na1 & !na2 & if.expand
  miss2 <- na2 & !na1 & if.expand
  miss12 <- na1 & na2 & if.expand
  leave.na <- (na1 | na2) & !if.expand
  n12 <- sum(miss12)
  nleave <- sum(leave.na)
  comp <- (!na1) & (!na2)
  rows <- 1:nrow(mat)
  col <- mat[miss1,2]
  rep1 <- cbind(rep(alleles, rep(length(col), nall)),rep(col, nall))
  col <- mat[miss2,1]
  rep2 <- cbind(rep(col, nall), rep(alleles, rep(length(col), nall)))
  rep12 <- cbind(rep(g1, n12), rep(g2, n12))
  replv <- matrix(NA, nrow=nleave, ncol=2)
  values <- rbind(mat[comp,], rep1, rep2, rep12, replv)
  pos <- c(rows[comp], rep(rows[miss1], nall), rep(rows[miss2], nall),
           rep(rows[miss12], rep(ngen, n12)), rows[leave.na])
  list(expanded = values, in.old = pos)
}

## Replace some rows  with two rows, remove any rows with NA

expand.phase <- function(mat, if.expand) {
  N <- nrow(mat)
  nas <- is.na(mat[,1]) | is.na(mat[,2]) 
  het <- if.expand & !nas
  hom <- !if.expand & !nas
  het.rows <- (1:N)[het]
  hom.rows <- (1:N)[hom] 
  add <- cbind(mat[het,2], mat[het,1])
  list(expanded = rbind(mat[hom,], mat[het,], add),
       in.old = c(hom.rows, het.rows, het.rows))
}

## EM algorithm for two loci. Designed to be called by em.haplotype
## Markers to be stored as 3-level factors or allele pairs (character matrices)

phase2 <- function(marker1, marker2, id=1:length(marker1), by=NULL,
                    min.posterior=0.01, delta.logL = 0.0001,
                    expand.missing=!(is.na(marker1) & is.na(marker2)),
                    random.start=FALSE) {
  if (is.factor(marker1)) {
    mat1 <- allelePair(marker1)
  } else {
    if (!(is.matrix(marker1)&&ncol(marker1)==2))
      stop("marker must be a factor or a 2-column matrix")
    mat1 <- marker1
  }
  N <- nrow(mat1)
  if (is.factor(marker2)) {
    mat2 <- allelePair(marker2)
  } else {
    if (!(is.matrix(marker2)&&ncol(marker2)==2))
      stop("marker must be a factor or a 2-column matrix")
    mat2 <- marker2
  }
  if (nrow(mat2)!=N)
    stop("Incompatible argument lengths")
  old <- 1:N
  xp <- expand.missing.genotype(mat1, if.expand=expand.missing)
  if (!is.null(xp)) {
    mat1 <- xp$expanded
    old <- old[xp$in.old]
    mat2 <- mat2[xp$in.old,]
  }
  xp <- expand.missing.genotype(mat2, if.expand=expand.missing[xp$in.old])
  if (!is.null(xp)) {
    mat2 <- xp$expanded
    old <- old[xp$in.old]
    mat1 <- mat1[xp$in.old,]
  }
  doublehet <- (mat1[,1]!=mat1[,2]) & (mat2[,1]!=mat2[,2])
  xp <- expand.phase(mat2, doublehet)
  mat2 <- xp$expanded
  old <- old[xp$in.old]
  mat1 <- mat1[xp$in.old,]
  newhap <- hbind(mat1, mat2)
  ##  cbind(paste(mat1[,1], mat2[,1], sep=sep), paste(mat1[,2], mat2[,2], sep=sep))
  fachap <- factor(newhap)
  New <- length(xp$in.old)
  first <- as.numeric(fachap[1:New])
  second <- as.numeric(fachap[(New+1):(2*New)])
  if (random.start)
    post <- runif(New)
  else
    post <- rep(1, New)
  id <- id[old]
  pid <- factor(id)
  nid <- as.numeric(pid) 
  psum <- tapply(post, pid, sum)
  post <- post/psum[nid]
  if (is.null(by)) {
    hby <- list(fachap)
    nby <- 0
  }
  else {
    if (!is.null(by) && !is.list(by))
      by <- list(by)
    nby <- length(by)
    hby <- vector("list", nby+1)
    ss <- matrix(nrow=New, ncol=nby)
    hby[[1]] <- fachap
    for (i in 1:nby) {
      byf <- by[[i]][old]
      if (any(is.na(byf)))
        stop("NAs in by variable(s)")
      hby[[i+1]] <- rep(byf, 2)
      ss[,i] <- as.numeric(byf)
    }
    first <- cbind(first, ss)
    second <- cbind(second, ss)
  }
  convg <- 0
  it <- 0
  while (convg < 2) {
    it <- it+1
    sum.post <- tapply(rep(post, 2), hby, sum)
    if (nby==0)
      new.prior <- sum.post/sum(sum.post)
    else {
      rest <- 2:(nby+1)
      new.prior <- sweep(sum.post, rest, apply(sum.post, rest, sum), "/")
    }
    post <- new.prior[first]*new.prior[second]
    psum <- tapply(post, pid, sum)
    post <- post/psum[nid]
    logL <- sum(log(psum))
    if (it > 2) {
      rise <- logL - last.logL
      if (rise<0)
        stop("Likelihood falling at stage ", convg+1, ", iteration ", it)
      if (rise < delta.logL) {
        convg <- convg + 1
        if (convg == 1) {
          drop <- post < min.posterior
          ndrop <- sum(drop)
          if (ndrop > 0) {
            post[drop] <- 0
            psum <- tapply(post, pid, sum)
            post <- post/psum[nid]
            it <- 0
          }
          else {
            convg <- convg + 1
          }
        }
      }
    }
    last.logL <- logL
  }
  if (ndrop > 0) {
    keep <- !drop
    newhap <- newhap[keep,]
    old <- old[keep]
    id <- id[keep]
    post <- post[keep]
  }
  names(post) <- as.character(id)
  list(phased=newhap, id=id, in.old=old,
       posterior=post, frequency=new.prior, logL = logL)
}

## This is the main user-callable function
## Could be improved by phasing down a dendrogram?      

phase <-  function(..., id, by=NULL, min.posterior=0.01,
                          delta.logL = 0.0001, random.start=FALSE) {
  args <- list(...)
  if (length(args)==1) {
    args <- args[[1]]
    if (!is.list(args))
      stop("Single unnamed argument must be a list")
  }
  M <- length(args)
  if (missing(id)) {
    N <- length(args[[1]])
    id <- 1:N
  }
  else
    N <- length(id)
  all.missing <- rep(TRUE, N)
  for (i in 1:M) {
    if (!is.Genotype(args[[i]]))
      stop("Unnamed arguments must be Genotype variables")
    if (length(args[[i]])!=N)
      stop("Unnamed arguments and/or id of unequal length")
    all.missing <- all.missing & is.na(args[[i]])
  }
  if (!is.null(by) && !is.list(by))
    by <- list(factor(by))
  nby <- length(by)
  if (nby > 0) {
    complete <- rep(TRUE, N)
    for (i in 1:nby) {
      if (length(by[[i]]) != N)
        stop("Illegal length object(s) in by list")
      by[[i]] <- as.factor(by[[i]])
      complete <- complete & !is.na(by[[i]])
    }
    in.old <- (1:N)[complete]
    res <- args[[1]][complete]
    id <- id[complete]
    byv <- vector("list", nby)
  }
  else {
    in.old <- 1:N
    res <- args[[1]]
    byv <- by
  }
  for (i in 2:M) {
    nxt <- args[[i]][in.old]
    if (nby > 0) {
      for (j in 1:nby)
        byv[[j]] <- by[[j]][in.old]
    }
    em2 <- phase2(res, nxt, id, by=byv, min.posterior=min.posterior,
                   delta.logL=delta.logL, expand.missing=!all.missing,
                   random.start=random.start)
    res <- em2$phased
    id <- em2$id
    in.old <- in.old[em2$in.old]
  }
  em2$in.old <- in.old
  em2
}

