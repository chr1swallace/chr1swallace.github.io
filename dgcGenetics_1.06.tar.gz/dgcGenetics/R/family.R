##
## Identify trios offspring and both parents
##

trios <- function(pedigree, id, id.father, id.mother, affected, 
                  codes = NULL, first=FALSE, data=parent.frame()) {
  cl <- match.call()
  if (missing(pedigree))
    pedigree <- eval(as.symbol("pedigree"), data)
  else
    pedigree <- eval(cl$pedigree, data)
  if (missing(id))
    id <- eval(as.symbol("id"), data)
  else
    id <- eval(cl$id, data)
  if (missing(id.father))
    id.father <- eval(as.symbol("id.father"), data)
  else
    id.father <- eval(cl$id.father, data)
  if (missing(id.mother))
    id.mother <- eval(as.symbol("id.mother"), data)
  else
    id.mother <- eval(cl$id.mother, data)
  if (!is.null(codes)) {
    if (missing(affected))
      affected <- eval(as.symbol("affected"), data)
    else
      affected <- eval(cl$affected, data)
    if (is.factor(affected))
      affected <- as.numeric(affected)
    select <- affected %in% codes
  }
  else
    select <- TRUE

  pid <- paste(pedigree, ":", id, sep="")
  fid <- paste(pedigree, ":", id.father, sep="")
  mid <- paste(pedigree, ":", id.mother, sep="")
  N <- length(pid)
  if (length(fid)!=N || length(mid)!=N ||
      (length(select)!=N && length(select)!=1))
    stop("arguments have unequal lengths")
  pos <- 1:N
  fpos <- match(fid, pid)
  mpos <- match(mid, pid)
  istrio <- !is.na(fpos) & !is.na(mpos) & select
  if (first) {
    dup <- duplicated(pedigree[istrio])
    if (any(dup)) {
      out <- (pos[istrio])[dup]
      istrio[out] <- FALSE
    }
  } 
  data.frame(offspring=pos[istrio], father=fpos[istrio], mother=mpos[istrio],
       pedigree=pedigree[istrio])
}

isMatch <- function(x, to.select) {
  if (is.factor(x) && is.numeric(to.select))
    as.numeric(x) %in% to.select
  else
    x %in% codes
}


## Resolve a single genotype for trios into transmitted and untransmitted
## haplotypes
## If one.parent true, allows partial resolution when one parent is missing
## If one.parent.all true, only resolves these if resolution possible for
## either transmission from other parent
## If allow.ambiguous, resolutions which are ambiguous for parent of origin
## are allowed

phase.resolve <- function(offspring, mother, father, allow.ambiguous=FALSE,
                          one.parent=FALSE, one.parent.all=FALSE) {
  if (is.Genotype(offspring)) {
    a.o <- allelePair(offspring)
    na.o <- is.na(offspring)
    alleles <- attr(offspring, "allele.names")
  } else if (is.AllelePair(offspring)) {
    alleles <- unique(offspring)
    a.o <- offspring
    na.o <- is.na(offspring[,1])
  } else {
    stop("Argument offspring must be  factor or allele pair") 
  }
  if (is.Genotype(mother)) {
    a.m <- allelePair(mother)
    na.m <- is.na(mother)
  } else if (is.AllelePair(mother)) {
    a.m <- mother
    na.m <- is.na(mother[,1])
  } else {
    stop("Argument <mother> must be factor or allele pair") 
  }
  if (is.Genotype(father)) {
    a.f <- allelePair(father)
    na.f <-is.na(father)
  } else if (is.AllelePair(father)) {
    a.f <- father
    na.f <- is.na(father[,1])
  } else {
    stop("Argument <father> must be  factor or allele pair") 
  }
  full <- !(na.o | na.m | na.f)
  asis <- na.o | 
          ((na.m | a.o[,1]==a.m[,1] | a.o[,1]==a.m[,2]) &
           (na.f | a.o[,2]==a.f[,1] | a.o[,2]==a.f[,2]))
  swap <- na.o |
          ((na.f | a.o[,1]==a.f[,1] | a.o[,1]==a.f[,2]) &
           (na.m | a.o[,2]==a.m[,1] | a.o[,2]==a.m[,2]))
  asis <- ifelse(is.na(asis), TRUE, asis)
  swap <- ifelse(is.na(swap), TRUE, swap)
  misinherits <- (!asis) & (!swap)
  if (any(misinherits))
    warning(sum(misinherits), " misinheritances")
  homo <- !na.o & (a.o[,1]==a.o[,2])
  ambiguous <- asis & swap & !homo
  mat.t <- ifelse(swap, a.o[,2], a.o[,1])
  pat.t <- ifelse(swap, a.o[,1], a.o[,2])
  mat.u <- ifelse(mat.t==a.m[,1], a.m[,2], a.m[,1])
  pat.u <- ifelse(pat.t==a.f[,1], a.f[,2], a.f[,1])
  resolved <- full & (allow.ambiguous | !ambiguous)
  # Partial resolution if only one parent typed
  # (only carried out if possible for either transmission)
  if (one.parent) {
    m.only <- na.f & !(na.o | na.m)
    f.only <- na.m & !(na.o | na.f)
    if (one.parent.all)
      resolved <- resolved | ((m.only | f.only) & !ambiguous)
    else
      resolved <- resolved | ((m.only | f.only) & !ambiguous & !homo)
  }
  resolved <- resolved & !misinherits & (allow.ambiguous | !ambiguous)
  mat.t[!resolved] <- NA
  pat.t[!resolved] <- NA
  mat.u[!resolved] <- NA
  pat.u[!resolved] <- NA
  mlist <- (1:length(misinherits))[misinherits]
  tr <- cbind(mat.t, pat.t)
  un <- cbind(mat.u, pat.u)
  if (allow.ambiguous) {
    colnames(tr) <- NULL
    colnames(un) <- NULL
    list(trans=tr, untrans=un, misinherits=mlist, ambiguous=ambiguous)
  }
  else {
    colnames(tr) <- c("Maternal", "Paternal")
    colnames(un) <- c("Maternal", "Paternal")
    list(trans=tr, untrans=un, misinherits=mlist)
  }
}

## long.phase.resolve resolves phase of transmitted and untransmitted
## haplotypes, as lists of 2-column character matrices
## offspring, mother, father are lists of genotype variables

long.phase.resolve <- function(offspring, mother, father,
                               parent.of.origin=FALSE) {
  if (!(is.list(offspring) && is.list(mother) && is.list(father)))
    stop("Arguments should be lists of genotypes")
  nloci <- length(offspring)
  if (!(length(mother)==nloci && length(father)==nloci)) 
    stop("Arguments should be lists of same length")
  tr <- vector("list", nloci)
  un <- vector("list", nloci)
  locnames <- names(offspring)
  names(tr) <- locnames
  names(un) <- locnames
  if (is.matrix(offspring[[1]])) {
    ntr <- nrow(offspring[[1]])
  } else {
    ntr <- length(offspring[[1]])
  }
  resolved <- rep(TRUE, ntr)
  if (!parent.of.origin) {
    n.ambig<- rep(0, ntr)
    n.het.tr <- rep(0, ntr)
    n.het.un <- rep(0, ntr)
  }
  for (i in 1:nloci) {
    phi <- phase.resolve(offspring[[i]], mother[[i]], father[[i]],
                         allow.ambiguous = !parent.of.origin)
    tr[[i]] <- phi$trans
    un[[i]] <- phi$untrans
    resolved <- resolved & !is.na(phi$trans[,1]) & !is.na(phi$untrans[,1]) & 
      !is.na(phi$trans[,2]) & !is.na(phi$untrans[,2]) 
    if (!parent.of.origin) {
      resolved <- resolved & !phi$ambiguous
      n.ambig <- n.ambig + phi$ambiguous
      n.het.tr <- n.het.tr + (phi$trans[,1]!= phi$trans[,2])
      n.het.un <- n.het.un + (phi$untrans[,1]!= phi$untrans[,2])
    }
  }
  if (!parent.of.origin)
    resolved <- resolved | n.ambig==0 |
                             (n.ambig==1 & !(n.het.tr>1 | n.het.un>1))
  resolved[is.na(resolved)] <- FALSE
  for (i in 1:nloci) {
    tr[[i]][!resolved,] <- NA
    un[[i]][!resolved,] <- NA
}
  list(trans=tr, untrans=un, resolved=resolved)
}

## falk.rubinstein simply computes (multilocus) transmitted and untransmitted
##    genotypes
##

falk.rubinstein <- function(offspring, mother, father, as.allele.pair=FALSE) {
  if (!(is.list(offspring) && is.list(mother) && is.list(father)))
    stop("Arguments should be lists of genotypes")
  nloci <- length(offspring)
  if (!(length(mother)==nloci && length(father)==nloci)) 
    stop("Arguments should be lists of same length")
  tr <- vector("list", nloci)
  un <- vector("list", nloci)
  locnames <- names(offspring)
  names(tr) <- locnames
  names(un) <- locnames
  ntr <- length(offspring[[1]])
  misinherits <- rep(FALSE, ntr)
  any.missing <- FALSE
  for (i in 1:nloci) {
    a.m <- allelePair(mother[[i]])
    na.m <- is.na(a.m[,1])
    a.f <- allelePair(father[[i]])
    na.f <- is.na(a.f[,1])
    a.o <- allelePair(offspring[[i]])
    na.o <- is.na(a.o[,1])
    asis <- na.o | 
          ((na.m | a.o[,1]==a.m[,1] | a.o[,1]==a.m[,2]) &
           (na.f | a.o[,2]==a.f[,1] | a.o[,2]==a.f[,2]))
    swap <- na.o |
          ((na.f | a.o[,1]==a.f[,1] | a.o[,1]==a.f[,2]) &
           (na.m | a.o[,2]==a.m[,1] | a.o[,2]==a.m[,2]))
    asis <- ifelse(is.na(asis), TRUE, asis)
    swap <- ifelse(is.na(swap), TRUE, swap)
    cant <-  (!asis) & (!swap)
    misinherits <- misinherits | cant
    uni <- cbind(ifelse(asis,
                        ifelse(a.o[,1]==a.m[,1], a.m[,2], a.m[,1]),
                        ifelse(a.o[,1]==a.f[,1], a.f[,2], a.f[,1])),
                 ifelse(asis,
                        ifelse(a.o[,2]==a.f[,1], a.f[,2], a.f[,1]),
                        ifelse(a.o[,2]==a.m[,1], a.m[,2], a.m[,1]))
                 )
    any.missing <- any.missing | is.na(uni[,1]) | is.na(uni[,2]) |
       is.na(a.o[,1]) | is.na(a.o[,2])
    un[[i]] <- uni
    tr[[i]] <- a.o
  }
  if (any(misinherits))
    warning(sum(misinherits), " misinheritances")
    misinherits <- misinherits | any.missing
    if (any(misinherits)) {
    for (i in 1:nloci) {
      un[[i]][misinherits,1] <- NA
      un[[i]][misinherits,2] <- NA
      tr[[i]][misinherits,1] <- NA
      tr[[i]][misinherits,2] <- NA
    }
  }
  list(trans=tr, untrans=un)
}

## TDT test

tdt <- function(genotype, data = parent.frame(),
                pedigree, id, id.father, id.mother, affected, sex,
                codes=2, parent="both", robust=FALSE, first=FALSE,
                exact = TRUE) {
  if (is.na(match(parent, c("both", "mother", "father"))))
    stop("Unrecognized parent= argument")
  if (missing(genotype))
    stop("Missing genotype argument with no default")
  cl <- match.call()
  g <- eval(cl$genotype, data)
  if (!is.Genotype(g) || !is.Snp(g))
    stop("argument must be a diallelic Genotype")
  gname <- deparse(cl$genotype)
  if (missing(pedigree))
    ped <- evalq(pedigree, data)
  else
    ped <- eval(cl$pedigree, data)
  anames <- attr(g, "allele.names")
  nall <- length(anames)
  affected.codes <- codes
  tr <- trios(pedigree, id, id.father, id.mother, affected,
              codes=codes, first=first, data=data)
  g.cs <- g[tr$offspring]
  g.fr <- g[tr$father]
  g.mr <- g[tr$mother]
  ped.cs <- tr$pedigree
  res <- phase.resolve(g.cs, g.mr, g.fr, allow.ambiguous=(parent=="both"),
                       one.parent=TRUE)
  if (parent=="both") {
    tr <- rbind(res$trans[,1], res$trans[,2])
    un <- rbind(res$untrans[,1], res$untrans[,2])
    pe <- rbind(ped.cs, ped.cs)
  }
  else if (parent=="mother") {
    tr <- res$trans[,1]
    un <- res$untrans[,1]
    pe <- ped.cs
  }
  else if (parent=="father") {
    tr <- res$trans[,2]
    un <- res$untrans[,2]
    pe <- ped.cs
  }
  af <- table(un, dnn="Allele frequency")
  af <- af/sum(af)
  infmtv <- !is.na(tr) & !is.na(un) & (tr!=un)
  ninf <- sum(infmtv)
  tr <- tr[infmtv]
  un <- un[infmtv]
  pe <- pe[infmtv]
  trtab <- table(c(tr, un), rep(c(0,1), c(ninf, ninf)))
  anames.old <- anames
  anames <- rownames(trtab)
  anames.omitted <- setdiff(anames.old, anames)
  if (length(anames.omitted)>0) {
    warning("No informative transmissions for alleles: ",
            paste(anames.omitted, collapse=","))
  }
  nall <- length(anames)
  dimnames(trtab) <- list(anames, c("Transmitted", "Untransmitted"))
  S <- trtab[1,1] + trtab[1,2]
  D <- trtab[1,1] - trtab[1,2]
  if (robust && any(duplicated(pe))) {
    U <- ifelse(tr==anames[1], +1, -1)
    U <- tapply(U, pe, sum)
    D <- sum(U)
    S <- sum(U^2)
    exact <- FALSE
  }
  if (exact) {
    test <- trtab[1,]
    names(test) <- paste(anames, "transmitted")
    method <- "Transmission/Disequilibrium test (exact)"
    pram <- c(S, 0.5)
    names(pram) <- c("N", "p")
    pval <- binom.test(trtab[1,], alternative="two.sided")$p.value
  }
  else {
    test <- D^2/S
    names(test) <- "Chi-squared test"
    method <- "Transmission/Disequilibrium test (asymptotic)"
    pram <- 1
    names(pram) <- "DF"
    pval <- pchisq(test, 1, lower.tail=FALSE)
  }
  result <- list(statistic=test, parameter=pram, exact=exact,
                 p.value=pval,
                 method=method,
                 data.name=gname,
                 allele.frequencies=af,
                 informative.transmissions=trtab
               )
  class(result) <- "htest"
  result
}

## Make dataframe of cases and matched pseudo-controls

pseudocc <- function(...,  data = sys.frame(sys.parent()), 
                     pedigree, id, id.father, id.mother, sex, affected,
                     codes = 2, phase=TRUE, first=FALSE,
                     parent.of.origin=exchangeable,
                     exchangeable = FALSE) {
  if (exchangeable && !parent.of.origin)
    stop("Incompatible exchangeable and parent.of.origin options")
  if (parent.of.origin && !phase)
    stop("Incompatible phase and parent.of.origin options")
  nsep <- dgcOptions()$name.sep
  idsep <- dgcOptions()$id.sep
  asep <- dgcOptions()$allele.sep
  cl <- match.call()
  arg.names <- names(cl)
  narg <- length(arg.names)
  ng <- sum(arg.names=="")-1
  gnames <- character(ng)
  gts <- vector("list", ng)
  for (i in 2:narg) {
    if (arg.names[i]=="") {
      gnames[i-1] <- deparse(cl[[i]])
      gtsi<- eval(cl[[i]], data)
      if (!is.Snp(gtsi))
        stop(gnames[i-1], " is not a genotype variable")
      gts[[i-1]] <- gtsi
    }
  }
  names(gts) <- gnames
  if (missing(pedigree))
    pedigree <- evalq(pedigree, data)
  else
    pedigree <- eval(cl$pedigree, data)
  if (missing(id))
    id <- evalq(id, data)
  else
    id <- eval(cl$id, data)
  if (missing(id.father))
    id.father <- evalq(id.father, data)
  else
    id.father <- eval(cl$id.father, data)
  if (missing(id.mother))
    id.mother <- evalq(id.mother, data)
  else
    id.mother <- eval(cl$id.mother, data)
  tr <- trios(pedigree, id, id.father, id.mother, affected,
              codes=codes, first=first, data=data)
  pedigree <- tr$pedigree
  id <- id[tr$offspring]
  id.father <- id[tr$father]
  id.mother <- id[tr$mother]
  father <- mother <- offspring <- vector("list", ng)
  for (i in 1:ng) {
    offspring[[i]] <- gts[[i]][tr$offspring]
    father[[i]] <- gts[[i]][tr$father]
    mother[[i]] <- gts[[i]][tr$mother]
  }
  if (phase && ng>1) {
    extra <- 7
    out <- vector("list", 3*ng+7)
    hapname <- paste(gnames, sep="", collapse=nsep)
    if (nchar(hapname)>10)
      hapname <- "haplotype"
    names(out) <- c("set", "cc", "pedigree", "id", "id.father", "id.mother",
                    hapname, gnames, paste(gnames,"mother", sep=nsep),
                    paste(gnames, "father", sep=nsep))
  }
  else {
    extra <- 6
    out <- vector("list", 3*ng+6)
    names(out) <- c("set", "cc", "pedigree", "id", "id.father", "id.mother",
                    gnames, paste(gnames,"mother", sep=nsep),
                    paste(gnames, "father", sep=nsep))
  }    
  if (phase) {
    res <- long.phase.resolve(offspring, mother, father,
                              parent.of.origin=parent.of.origin)
    case <- res$trans
    untrans <- res$untrans
    res.case <- res$resolved
    off <- vector("list", ng)
    for (i in 1:ng) 
      off[[i]] <- cbind(untrans[[i]][,1], case[[i]][,2])
    res <- long.phase.resolve(off, mother, father,
                              parent.of.origin=parent.of.origin)
    control1 <- res$trans
    res.control1 <- res$resolved
    for (i in 1:ng) 
      off[[i]] <- cbind(case[[i]][,1], untrans[[i]][,2])
    res <- long.phase.resolve(off, mother, father,
                              parent.of.origin=parent.of.origin)
    control2 <- res$trans
    res.control2 <- res$resolved
    for (i in 1:ng) 
      off[[i]] <- cbind(untrans[[i]][,1], untrans[[i]][,2])
    res <- long.phase.resolve(off, mother, father,
                              parent.of.origin=parent.of.origin)
    control3 <- res$trans
    res.control3 <- res$resolved
    res.case <- res.case & (res.control1 | res.control2 | res.control3)
    set <- 1:length(res.case)
    n.case <- sum(res.case)
    n.control <- sum(res.control1) + sum(res.control2) + sum(res.control3)
    set <- c(set[res.case], set[res.control1], set[res.control2],
                 set[res.control3])
    cc <- c(rep(1, n.case), rep(0, n.control))
    ped <- c(pedigree[res.case], pedigree[res.control1],
                      pedigree[res.control2], pedigree[res.control3])
    id <- c(id[res.case], id[res.control1],
                id[res.control2], id[res.control3])
    fid <- c(id.father[res.case], id.father[res.control1],
                id.father[res.control2], id.father[res.control3])
    mid <- c(id.mother[res.case], id.mother[res.control1],
                id.mother[res.control2], id.mother[res.control3])
    if (exchangeable) {
      set1 <- set
      set <- rep(set, 2)
      cc <- c(cc, rep(0, length(cc)))
      ped <- rep(ped, 2)
      id <- rep(id, 2)
      fid <- c(fid, mid)
      mid <- c(mid, fid)
    }
    setord <- order(set)
    out$set <- set[setord]
    out$cc <- cc[setord]
    out$pedigree <- ped[setord]
    out$id <- id[setord]
    out$id.father <- fid[setord]
    out$id.mother <- mid[setord]
    for (i in 1:ng) {
      hapi <- rbind(case[[i]][res.case,],
                    control1[[i]][res.control1,],
                    control2[[i]][res.control2,],
                    control3[[i]][res.control3,])
      if (exchangeable)
        hapi <- rbind(hapi, cbind(hapi[,2], hapi[,1]))
      if (ng==1 && !parent.of.origin)
        out[[i+extra]] <- as.Genotype(hapi[setord,])
      else
        out[[i+extra]] <- as.OrderedGenotype(hapi[setord,])
    }
    if (phase && ng>1) {
      hap <- hbind(out[extra +(1:ng)])
      if (parent.of.origin)
        out[[extra]] <- as.OrderedGenotype(hap)
      else
        out[[extra]] <- as.Genotype(hap)
    }
    for (i in 1:ng)  {
      if (exchangeable) {
        pg1 <- rbind(allelePair(mother[[i]][set1]),
                             allelePair(father[[i]][set1]))
        pg2 <- rbind(allelePair(father[[i]][set1]),
                             allelePair(mother[[i]][set1]))
      } else {
        pg1 <- allelePair(mother[[i]][set])
        pg2 <- allelePair(father[[i]][set])
      }
      out[[i+ng+extra]] <- as.Genotype(pg1[setord,])
      out[[i+2*ng+extra]] <- as.Genotype(pg2[setord,])   }
  }
  else {
    res <- falk.rubinstein(offspring, mother, father)
    n.case <- nrow(res$trans[[1]])
    set <- rep(1:n.case, rep(2, n.case))
    out$set <- set
    out$cc <- rep(c(1,0), n.case)
    out$pedigree <- pedigree[set]
    out$id <- id[set]
    out$id.father <- id.father[set]
    out$id.mother <- id.mother[set]
    setord <- order(rep(1:n.case,2))
    for (i in 1:ng) 
      out[[i+extra]] <- as.Genotype(rbind(res$trans[[i]], res$untrans[[i]])[setord,])
    for (i in 1:ng)  
      out[[i+ng+extra]] <- mother[[i]][set]
    for (i in 1:ng) 
      out[[i+2*ng+extra]] <- father[[i]][set]
  }
  as.data.frame(out)
}

## Trio types for parent-of-origin analyses

trioTypes <- function(genotype, data = sys.frame(sys.parent()), 
                pedigree, id, id.father, id.mother, sex, affected,
                codes = 2, all=FALSE, first=FALSE, parent.of.origin=FALSE) {
  if (missing(genotype))
    stop("Missing genotype argument with no default")
  cl <- match.call()
  g <- eval(cl$genotype, data)
  gname <- deparse(cl$genotype) 
  tr <- trios(pedigree, id, id.father, id.mother, affected,
              codes=codes, first=first, data=data)
  g.cs <- g[tr$offspring]
  g.fr <- g[tr$father]
  g.mr <- g[tr$mother]
  df <- as.data.frame(table(g.cs, g.mr, g.fr))
  df.swap <- as.data.frame(table(g.cs, g.fr, g.mr))
  for (i in 1:3)
    df[[i]] <- as.Genotype(df[[i]])
  wl <- options()$warn
  options(warn=-1)
  pr <- phase.resolve(df[[1]], df[[2]], df[[3]], allow.ambiguous=TRUE)
  options(warn=wl)
  mendelian <- rep(TRUE, length(df[[1]]))
  mendelian[pr$misinherits] <- FALSE
  if (!all & any(!mendelian & (df[[4]]!=0)))
    warning("Non-Mendelian inheritances were observed")
  i.cs <- as.numeric(df[[1]])
  i.fr <- as.numeric(df[[2]])
  i.mr <- as.numeric(df[[3]])
  i.p1 <- ifelse(i.fr<i.mr, i.fr, i.mr)
  i.p2 <- ifelse(i.fr<i.mr, i.mr, i.fr)
  ord <- order(!mendelian, i.p1, i.p2, i.cs, i.mr)
  mendelian <- mendelian[ord]
  if (parent.of.origin) 
    pneq <- (i.fr!=i.mr)[ord]
  else
    pneq <- TRUE
  if (!all) {
    ord <- ord[mendelian & pneq]
    df.sort <- vector("list", 4)
    for (i in 1:4) {
      df.sort[[i]] <- df[[i]][ord]
    }
    names(df.sort) <- c("affected.offspring", "mother", "father", "frequency")
  }
  else {
    df.sort <- vector("list", 5)
    for (i in 1:4) {
      df.sort[[i]] <- df[[i]][ord]
    }
    df.sort[[5]] <- mendelian
    names(df.sort) <- c("affected.offspring", "mother", "father", "frequency",
                        "Mendelian")
  }
  as.data.frame(df.sort)            
} 

origin <- function(genotype, data = sys.frame(sys.parent()),
                pedigree, id, id.father, id.mother, sex, affected,
                codes = 2, first=TRUE, maternal.effect=FALSE, base=1) {
  cl <- match.call()
  g <- eval(cl$genotype, data)
  if (missing(pedigree))
    pedigree <- eval(as.symbol("pedigree"), data)
  else
    pedigree <- eval(cl$pedigree, data)
  N <- length(pedigree)
  if (missing(id))
    id <- eval(as.symbol("id"), data)
  else
    id <- eval(cl$id, data)
  if (missing(id.father))
    id.father <- eval(as.symbol("id.father"), data)
  else
    id.father <- eval(cl$id.father, data)
  if (missing(id.mother))
    id.mother <- eval(as.symbol("id.mother"), data)
  else
    id.mother <- eval(cl$id.mother, data)
  if (missing(sex))
    sex <- eval(as.symbol("sex"), data)
  else
    sex <- eval(cl$sex, data)
  if (missing(affected))
    affected <- eval(as.symbol("affected"), data)
  else
    affected <- eval(cl$affected, data)
  tr <- trioTypes(g, codes=codes, first=first, parent.of.origin=TRUE)
  n.pairs <- length(tr$affected.offspring)/2
  one <- rep(c(TRUE, FALSE), n.pairs)
  r <- tr$frequency[one]
  n <- r + tr$frequency[!one]
  p <- r/n
  ac <- alleleInc(tr$affected.offspring)
  mc <- alleleInc(tr$mother)
  fc <- alleleInc(tr$father)
  maternal.origin <- matrix(as.numeric((ac==2) | ((ac==1) & (mc>fc))), ncol=2)
  mother.1 <- matrix(as.numeric(mc==1), ncol=2)
  mother.2 <- matrix(as.numeric(mc==2), ncol=2)
  colnames(maternal.origin) <- attr(tr$affected.offspring, "allele.names")
  colnames(mother.1) <- attr(tr$affected.offspring, "allele.names")
  colnames(mother.2) <- attr(tr$affected.offspring, "allele.names")
  maternal.origin <- maternal.origin[, -base, drop=FALSE]
  mother.1 <- mother.1[, -base, drop=FALSE]
  mother.2 <- mother.2[, -base, drop=FALSE]
  mother <- cbind(mother.1, mother.2)
  maternal.origin <- maternal.origin[one,] - maternal.origin[!one,]
  mother <- mother[one,] - mother[!one,]
  if (!maternal.effect) {
    g <- glm(p ~ -1 + maternal.origin, family=binomial,
             weights=n)
  }
  else {
    g <- glm(p ~ -1 + mother + maternal.origin, family=binomial,
             weights=n)
  }
  anova(g)
}
